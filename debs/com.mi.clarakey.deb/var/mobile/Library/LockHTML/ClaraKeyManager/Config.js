var PurchaseKey = "ENTER YOUR KEY HERE"; // Enter your Purchase Key.
