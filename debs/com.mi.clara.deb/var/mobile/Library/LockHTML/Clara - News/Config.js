var NewsCountry = "us";
var NumberOfNews = "4"; // Set "1" to "5"
var AdjustBackgroundColor = "3"; // Adjust the background color. Use "0" to "5"
var CustomBackgroundColor = false; 
var CustomColorHex = "20a47c"; // Add your custom Hex color
var CustomOpacity = "7"; // Background opacity. Set 1 to 9
var TextAlign = "left"; // Set "left", "center" or "right"
