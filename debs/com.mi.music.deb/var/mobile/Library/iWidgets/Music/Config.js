var Background = true; 
var TextColor = "fff"; 
